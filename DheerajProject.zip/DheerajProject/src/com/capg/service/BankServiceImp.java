package com.capg.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.capg.bean.Customer;
import com.capg.dao.BankDaoImp;
import com.capg.exception.InvalidInputException;

public class BankServiceImp implements IBankService {
	BankDaoImp dao = new BankDaoImp();

	@Override
	public boolean CreateAccount(Customer c) {

		return dao.CreateAccount(c);
	}

	public boolean validation(Customer bean) {
		boolean flag = false;
		if (isValidName(bean.getName()) && isValidaddress(bean.getAddress()) && isValidemail(bean.getEmail())
				&& isValidphonenumber(bean.getPhonenumber()) && isValiddob(bean.getDateofbirth())
				&& isValidcustomerid(bean.getCustomerid())) {
			flag = true;
		}
		return flag;
	}

	public boolean isValidName(String name) {
		if (((name != null) && name.matches("[A-Z][a-z]+"))) {
			return true;
		} else {
			throw new InvalidInputException(" : Name cannot be NULL (or) INVALID Name.");
		}
	}

	public boolean isValidaddress(String address) {
		if (((address != null) && address.matches("[0-9]"))) {
			return true;
		} else {
			throw new InvalidInputException(" : address cannot be NULL (or) INVALID address.");
		}
	}

	public boolean isValidemail(String email) {
		if (((email != null) && email.matches(
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"))) {
			return true;
		} else {
			throw new InvalidInputException(" : email cannot be NULL (or) INVALID email.");
		}
	}

	public boolean isValidphonenumber(String phonenumber) {
		if (((phonenumber != null) && phonenumber.matches("[4-9][0-9]{9}"))) {
			return true;
		} else {
			throw new InvalidInputException(" : Name cannot be NULL (or) INVALID Name.");
		}
	}

	public boolean isValiddob(String dob) {
		if (((dob != null) && dob.matches("^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$"))) {
			return true;
		} else {
			throw new InvalidInputException(" : dob cannot be NULL (or) INVALID dob.");
		}
	}

	public boolean isValidcustomerid(int customerid) {
		if (customerid >= 100) {
			return true;
		} else {
			throw new InvalidInputException(" : customerid cannot be Null (or) INVALID Customer.");
		}
	}

	public boolean validAmount(int amount) {
		if (amount > 0) {
			return true;
		} else {
			throw new InvalidInputException(" : Invalid Amount. Please enter a POSITIVE amount. Thanks. :) \n");
		}
	}

	@Override
	public Customer ShowBalance(int customerid, int pin) {
		Customer disp = displayCustomer(customerid);
		int bal1 = 0;
		if (disp.getCustomerid() == customerid && disp.getPin() == pin) {
			bal1 = disp.getBalance();
		}
		return dao.ShowBalance(customerid, bal1);
		// TODO Auto-generated method stub
	}

	@Override
	public Customer Deposit(int amount, int customerid1) {
		Customer disp = displayCustomer(customerid1);

		amount = disp.getBalance() + amount;
		disp.setBalance(amount);
		return dao.Deposit(amount, customerid1);

	}


	@Override
	public Customer Withdraw(int withdraw, int customerid2) {
		Customer disp = displayCustomer(customerid2);

		withdraw = disp.getBalance() - withdraw;
		disp.setBalance(withdraw);
		return dao.Withdraw(withdraw, customerid2);

	}

	
	
	
	
	
	@Override
	public Customer FundTransfer( int transferid,int transferamount,int customerid3) {
		// TODO Auto-generated method stub
		Customer disp = displayCustomer(transferid);
	Customer bal = null;
	Customer bal1=null;
	if(disp.getCustomerid()==transferid) {
		 bal=Deposit(transferamount,transferid);
		Customer disp1 = displayCustomer(transferid);
		bal1=Withdraw(transferamount,customerid3);
	}
	
	
	
	
		/*if(disp.getCustomerid()==transferid) {
		 bal=disp.getBalance()+transferamount;
		disp.setBalance(bal);
		Customer disp1 = displayCustomer(customerid3);
		 bal1=disp1.getBalance()-transferamount;
		disp1.setBalance(bal1);}*/
		return dao.FundTransfer(bal,bal1,customerid3);
			
			
		
		
	}
		

	@Override
	public List<String>PrintTransactions(int customerid) {
		// TODO Auto-generated method stub
return dao.PrintTransactions(customerid);
	}

	@Override
	public Customer displayCustomer(int cid) {
		// TODO Auto-generated method stub
		return dao.displayCustomer(cid);
	}

	public boolean access(int customerid1, int pin1) {
		Customer disp = displayCustomer(customerid1);
		boolean flag = false;
		if (disp.getCustomerid() == customerid1 && disp.getPin() == pin1) {
			{
				flag = true;
			}
		}
		return flag;
	}

}
