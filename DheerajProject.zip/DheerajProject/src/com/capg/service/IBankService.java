package com.capg.service;

import java.util.List;

import com.capg.bean.Customer;

public interface IBankService {
	
	public boolean CreateAccount(Customer c);
	public Customer ShowBalance(int customerid,int pin);
	public Customer Deposit(int amount,int customerid1);
	
	public Customer displayCustomer(int cid);
	Customer Withdraw(int withdraw, int customerid2);
	
	Customer FundTransfer(int transferid, int transferamount, int customerid3);
	
	public List<String> PrintTransactions(int customerid);
	
	

	
	
	
	
	
}
