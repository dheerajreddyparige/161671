package com.capg.bean;

public class Customer {
	 int pin = (int) ((Math.random() * 100));
	 int accountnumber = (int) ((Math.random() * 40000) + 1000);



	int customerid = (int) ((Math.random() * 100) + 1000);

	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", name=" + name
				+ ", address=" + address + ", phonenumber=" + phonenumber
				+ ", email=" + email + ", dateofbirth=" + dateofbirth
				+ ", accountnumber=" + accountnumber + ",balance=" + balance
				+ ",pin=" + pin + "]";
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public String getName() {
		return name;
	}


	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	String name;
	String address;
	String phonenumber;
	String email;
	String dateofbirth;
	int balance = 0;

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
}
