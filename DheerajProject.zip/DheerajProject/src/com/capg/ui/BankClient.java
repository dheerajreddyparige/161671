package com.capg.ui;

import java.util.Scanner;

import javax.swing.plaf.synth.SynthSplitPaneUI;

import com.capg.bean.Customer;
import com.capg.service.BankServiceImp;

public class BankClient {

	public static void main(String[] args) {
		BankServiceImp service = new BankServiceImp();
		while (true) {

			System.out.println("Select an option ");
			System.out.println("1.Create Account ");
			System.out.println("2.Show Balance ");
			System.out.println("3.Deposit ");
			System.out.println("4.Withdraw ");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions ");

			Scanner sc = new Scanner(System.in);
			int sel = sc.nextInt();

			switch (sel) {
			case 1:
				Customer bean = new Customer();
				System.out.println("Enter ur Name");
				String name = sc.next();
				System.out.println("Enter customer address");
				String address = sc.next();
				System.out.println("Enter customer phone number");
				String phonenumber = sc.next();
				System.out.println("Enter email");
				String email = sc.next();
				System.out.println("Enter date of birth");
				String dateofbirth = sc.next();
				
			  bean.getCustomerid(); bean.getAccountnumber(); bean.getPin();
				 
				bean.setName(name);
				bean.setAddress(address);
				 bean.getBalance();
				bean.setPhonenumber(phonenumber);
				bean.setEmail(email);
				bean.setDateofbirth(dateofbirth);
				boolean correct = service.validation(bean);
				if (correct) {
					boolean isAdded = service.CreateAccount(bean);
					if (isAdded) {
						System.out.println("Record added sucessfully");
						System.out.println(bean);

					} else {
						System.err.println("Record not added..");
					}
				} else {
					System.err.println("this is error");

				}

				break;
			case 2:
				Customer bean1 = new Customer();
				System.out.println("enter your customer id");
				int customerid = sc.nextInt();
				System.out.println("enter ur pin");
				int pin = sc.nextInt();
				Customer disp = service.ShowBalance(customerid, pin);

				System.out.println("Balance in your account is:"+disp.getBalance());

				break;

			case 3:
				Customer bean2 = new Customer();
				System.out.println("enter your customer id");
				int customerid1 = sc.nextInt();
				System.out.println("enter ur pin");
				int pin1 = sc.nextInt();

				boolean correct2 = service.access(customerid1, pin1);
				if (correct2) {
					System.out.println("enter amount to deposit");
					int amount = sc.nextInt();

					Customer disp1 = service.Deposit(amount, customerid1);
					System.out.println("Amount Deposited:" + amount);

					System.out.println("Current balance:" + disp1.getBalance());
				}
				/*
				 * boolean amountcorrect=service.validAmount(amount);
				 * 
				 * if(amountcorrect){
				 * 
				 * int bal=service.Deposit(amount,bean2);
				 * 
				 * System.out.println("Deposited amount is "+amount+"newBalance: "+bal); }
				 * 
				 * 
				 * }else{System.out.
				 * println("Invalid Amount. Please enter a POSITIVE amount. Thanks. :");}
				 */

				break;

			case 4:

				Customer bean3 = new Customer();
				System.out.println("enter your customer id");
				int customerid2 = sc.nextInt();
				System.out.println("enter ur pin");
				int pin2 = sc.nextInt();

				boolean correct3 = service.access(customerid2, pin2);
				if (correct3) {
					System.out.println("enter amount to withdraw");
					int withdraw = sc.nextInt();

					Customer disp2 = service.Withdraw(withdraw, customerid2);
					System.out.println("Amount withdrawn:" + withdraw);

					System.out.println("Current balance:" + disp2.getBalance());
				}
				break;
			case 5:
				Customer bean4 = new Customer();
				System.out.println("enter your customer id");
				int customerid3 = sc.nextInt();
				System.out.println("enter ur pin");
				int pin3 = sc.nextInt();

				boolean correct4 = service.access(customerid3, pin3);
				if (correct4) {
					System.out.println("Enter customerid to transfer");
					int transferid = sc.nextInt();
					System.out.println("Enter amount to transfer");
					int transferamount = sc.nextInt();
					Customer disp3 = service.FundTransfer(transferid, transferamount, customerid3);
					System.out.println("Money transfered to id:"+ transferid );
					System.out.println("Total Money Transfered is:" + transferamount);
					System.out.println("Balance in ur account:"+ disp3.getBalance());
				}
				break;
				
			case 6:	Customer bean5 = new Customer();
			System.out.println("enter your customer id");
			int customerid4 = sc.nextInt();
			System.out.println("enter ur pin");
			int pin4 = sc.nextInt();

			boolean correct5 = service.access(customerid4, pin4);
			if (correct5) {
				System.out.println(service.PrintTransactions(customerid4));
				
				
			}
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			}
		}
	}
}
