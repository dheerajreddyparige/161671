package com.capg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capg.bean.Customer;
import com.capg.exception.InvalidInputException;

public class BankDaoImp implements IBankDao {

	private static Map<Integer, Customer> account = new HashMap<Integer, Customer>();
	Map<Integer, List<String>> transactions = new HashMap<Integer, List<String>>();
	List<String> list = new ArrayList<String>();

	public boolean CreateAccount(Customer c) {
		// TODO Auto-generated method stub
		int key = c.getCustomerid();
		account.put(key, c);
		
		return account.containsValue(c);
	}

	public Customer ShowBalance(int customerid, int bal1) {
		
		return account.get(customerid);}
		/*for(Customer c:account.values())
			if (c.getCustomerid() == customerid && c.getPin() == pin) {
				
				
			}
		return flag;}}*/


	@Override
	public Customer Deposit(int amount,int customer1) {
		
	 return account.get(customer1);
		
	}

	
	

	
	@Override
	public Customer displayCustomer(int cid) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for (Customer c : account.values()) {
			if(c.getCustomerid()==cid){
				cust=c;
			}
		}
		return cust;
	}

	public Customer Withdraw(int withdraw, int customerid2) {
		// TODO Auto-generated method stub
		return account.get(customerid2);
	}

	public Customer FundTransfer(Customer bal, Customer bal1, int customerid3) {
		// TODO Auto-generated method stub
		return account.get(customerid3);
	}

	public List<String> PrintTransactions(int customerid) {
		if(transactions.containsKey(customerid)) {
			return transactions.get(customerid);
		}
		else {
			throw new InvalidInputException(" : Invalid customerid.");
		}
		
	}

	

	
}
