package com.capg.dao;

import java.util.List;

import com.capg.bean.Customer;

public interface IBankDao {
	
	public boolean CreateAccount(Customer c);

	public Customer Withdraw(int amount, int customerid1);	
	public Customer FundTransfer(Customer bal, Customer bal1, int customerid3);
	public List<String> PrintTransactions(int customerid);
	public Customer ShowBalance(int customerid,int pin);
public Customer displayCustomer(int cid);
	public Customer Deposit(int amount, int customerid1);









	


	
}
