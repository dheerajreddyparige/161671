package com.capgemini.doctors.dao;

import java.util.TreeMap;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DrSmartException;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	TreeMap<Integer,DoctorAppointment> appointments=new TreeMap<Integer,DoctorAppointment>();
		// TODO Auto-generated method stub
		
		
		public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment){
			doctorAppointment.getAppointmentId();
			appointments.put(doctorAppointment.getAppointmentId(), doctorAppointment);
return doctorAppointment.getAppointmentId();		}
		
		
		public DoctorAppointment getDoctorAppointmentDetails(int appointmentid)throws DrSmartException{
			
			if(appointments.containsKey(appointmentid))
			{
				return appointments.get(appointmentid);
			}
		else 
			throw new DrSmartException("NO appointment Found:");
		
		
		
		
		
		
		
	}

}
