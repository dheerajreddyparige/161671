package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DrSmartException;
import com.capgemini.doctors.service.DoctorAppointmentService;



public class Client {

	public static void main(String[] args) throws DrSmartException {
		// TODO Auto-generated method stub
boolean nameFlag=false,phoneNoFlag=false,emailFlag=false,ageFlag=false,genderFlag=false;
String name,phoneNo,email,gender,problemName;
int age;
int choice,appointmentid;
Scanner get=new Scanner(System.in);
DoctorAppointmentService service=new DoctorAppointmentService();
do{
	System.out.println("\n*********** DrSmart Service****************");
	System.out.println("Choose an operation");
	System.out.println("1. Book Doctor Appointment");
	System.out.println("2.View Doctor Appointment");
	System.out.println("3.Exit");
	System.out.println("*****************");
	System.out.println("\nPlease Enter a Choice");
	choice=get.nextInt();
	System.out.println("****************");
	switch(choice)
	{
	case 1://Creating a new Account for the user
	{
	//customer name
		do
		{
			System.out.println("Enter the name of the patient");
			name=get.next();
			nameFlag=service.validateName(name);
			if(nameFlag==false)
				System.out.println("Name should be Entered properly format(eg.robert)");
		}while(nameFlag==false);
	
		//Customer phone number
		do
		{
			System.out.println("Enter phone number:");
			phoneNo=get.next();
			phoneNoFlag=service.validatePhoneNumber(phoneNo);
			if(phoneNoFlag==false)
				System.out.println("Phonenumber should be a 10digit");
		}while(phoneNoFlag==false);
		
		//getting email Id
		
		do
		{
			System.out.println("Enter Email ID:");
			email=get.next();
			emailFlag=service.validateEmail(email);
			if(emailFlag==false)
				System.out.println("Email id should be in proper format eg:abc123@gmail.com");
		}while(emailFlag==false);
		
		//Customer Age
		do
		{
			System.out.println("Enter Age");
			age=get.nextInt();
			ageFlag=service.validateAge(age);
			if(ageFlag==false)
				System.out.println("Age should be below 110");
		}while(ageFlag==false);
		
		//getting gender of the patient
		do{
			System.out.println("Enter Gender");
			gender=get.next();
			genderFlag=service.validateGender(gender);
			if(genderFlag==false)
				System.out.println("incorrect value");
		}while(genderFlag==false);
		
		//getting the problem name of the patient
		System.out.println("Enter the Problem Name:");
		problemName=get.next();
		
		//setting the values
		DoctorAppointment newPatient=new DoctorAppointment();
		newPatient.setPatientName(name);
		newPatient.setAge(age);
		newPatient.setPhoneNumber(phoneNo);
		newPatient.setGender(gender);
		newPatient.setEmail(email);
		newPatient.setProblemName(problemName);
		appointmentid=service.addDoctorAppointmentDetails(newPatient);
		System.out.println("Your Doctor Appointment has been succesfully registered,\nYour appointmentId is:"+appointmentid);
		break;
	}
	case 2:
	{
		//pwdFlag=false;
		System.out.println("\n******************DrSmart Service***************");
		System.out.println("Enter the AppointmentID:");
		//logic for user id check
		appointmentid=get.nextInt();
		try{
			DoctorAppointment temp= service.getDoctorAppointmentDetails(appointmentid);
			System.out.println("\n******************DrSmart Services**********");
			System.out.println("PatientName"+temp.getPatientName());
			System.out.println("appointment Status:"+temp.getAppointmentStatus());
			System.out.println("Doctor Name:"+temp.getDoctorName());
			System.out.println("******************");
	System.out.println("Apppointment Date and Time,along with doctors's phone number\n will be shared shortly with you:");
	System.out.println("**********************");
		}catch(DrSmartException e){
			System.out.println(e.getMessage());
		}
		break;
	}
	case 3:
		System.out.println("Thank You");
		System.exit(0);
	break;
	
	
	
	
	
}
	
	System.out.println("Do you want to continue?1.Yes 0-No");
	choice=get.nextInt();
	}while(choice==1);

}}
