package com.capgemini.doctors.Test;

import static org.junit.Assert.assertEquals;

import javax.security.auth.login.AccountException;

import org.junit.Test;

import com.capgemini.doctors.service.DoctorAppointmentService;

public class TestCase {

	
	@Test(expected=AccountException.class)
	public void ValidateMobileNumber_v1() throws AccountException {
		DoctorAppointmentService accservice=new DoctorAppointmentService();
		accservice.validateName(null);
		
	}
	@Test
	public void ValidateMobileNumber_v2() throws AccountException  { //less than 10digits
		DoctorAppointmentService accservice=new DoctorAppointmentService();
		boolean result=accservice.validateEmail("62");
		assertEquals(false, result);
		
	}
	
	@Test
	public void ValidateMobileNumber_v3() throws AccountException  { //not number digits
		DoctorAppointmentService accservice=new DoctorAppointmentService();
		boolean result=accservice.validatePhoneNumber("jhsgdjg");
		assertEquals(false, result);
		
	}

	
	
	
	}
	
	



