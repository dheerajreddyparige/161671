package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DrSmartException;

public interface IDoctorAppointmentService {
int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment);
DoctorAppointment getDoctorAppointmentDetails(int appointmentId)throws DrSmartException;
}
