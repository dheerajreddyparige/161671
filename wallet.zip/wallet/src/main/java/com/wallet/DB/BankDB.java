package com.wallet.DB;

import java.util.HashMap;

import com.wallet.bean.Customer;

public class BankDB {
private static HashMap<Integer,Customer> customerMap=new HashMap<Integer,Customer>();
static {
	customerMap.put(1001, new Customer(1001,"sush","8939628680","sush@gmail.com","Chennai",100000,132,null));
	customerMap.put(1002, new Customer(1002,"Pam","8888888888","pam@outlook.com","Banglore",150000,123,null));
	customerMap.put(1003, new Customer(1003,"Sara","7777777777","sara@ymail.com","Chennai",200000,321,null));
	customerMap.put(1004, new Customer(1004,"Ben","6666666666","ben@gmail.com","Hyderbad",400000,111,null));
	customerMap.put(1005, new Customer(1005,"Anil","9898989898","anil@gmail.com","Delhi",250000,122,null));
	customerMap.put(1006, new Customer(1006,"Sunil","67676767679","sunil@gmail.com","Pune",300000,333,null));
}

public static HashMap<Integer,Customer> getCustomerMap(){
	return customerMap;
}
}
