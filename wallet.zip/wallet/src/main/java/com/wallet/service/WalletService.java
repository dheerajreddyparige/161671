package com.wallet.service;

import java.util.Collection;

import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public interface WalletService {
	Customer showBalance(int accNumber) throws WalletException;
	int createAccount(Customer cust)  throws WalletException;
	boolean deposit(int num,double amount) throws WalletException; 
	boolean validateCustomer(Customer cust) throws WalletException;
	boolean withdraw(int num,double amount) throws WalletException; 
	boolean fundTransfer(int num,int num1,double amount) throws WalletException; 
	String printTransaction(int num) throws WalletException;
}
